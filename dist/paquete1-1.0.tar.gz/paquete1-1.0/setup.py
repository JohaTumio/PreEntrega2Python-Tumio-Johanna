from setuptools import setup

setup(
    name="paquete1",
    version="1.0", 
    description="Segunda preEntrega",
    author="Johanna Tumio",
    author_email="johatumio@hotmail.com",
    packages=["paquete1"]
)
